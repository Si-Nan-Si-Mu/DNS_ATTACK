# Windows 版 DNS 劫持演示

`dns-hijack-win.py` —— 在 Windows 上做 DNS 劫持演示。

**先说最关键的一点**：Linux 版靠 network namespace 把整套攻击关在进程级
的"小盒子"里，出不去。**Windows 没有这个机制**，所以只有两条路 ——
改本机配置（安全），或对局域网做 ARP 欺骗（有风险，需授权）。脚本两种
模式都做了，默认推荐安全的那种。

---

## 两种模式

### local —— 本地模式（推荐，安全）

在本机起一个「恶意 DNS」和一个「仿冒网站」，然后把自己电脑的 DNS 临时
指向 `127.0.0.1`。浏览器访问 `www.baidu.com` 就会落到钓鱼页。

- ✅ 只影响这一台机器，零网络风险
- ✅ 学生可以各自在自己电脑上跑，互不干扰
- ✅ 零额外依赖（只用 Python 标准库）

### lan —— 局域网模式（危险，需授权）

对同网段的目标机器做 ARP 欺骗 + DNS 抢答，让它把 `www.baidu.com` 解析到
你的假站。

⚠️ **这是对真实网络发起攻击**：

- ARP 欺骗在广播域内生效，**同网段其他设备也可能中招**
- 如果转发没配好，目标机器会**直接断网**
- 校园网 / 公司网做这个通常违反规定，**必须拿到网络管理员授权**

需要：管理员权限 + Npcap + `pip install scapy`

---

## 环境准备

**local 模式**：只需要 Python 3。

```powershell
python --version
```

**lan 模式**：额外装 Npcap（https://npcap.com/#download，安装时勾选
"WinPcap API-compatible Mode"），再 `pip install scapy`。

---

## local 模式操作步骤

全部在**管理员 PowerShell**里执行（绑定 53/80 端口需要管理员权限）。

```powershell
# 1. 先看网卡名（后面要用）
netsh interface show interface

# 2. 启动演示服务
python dns-hijack-win.py local

# 3. 另开一个管理员 PowerShell，把 DNS 指向本机
netsh interface ip set dns "以太网" static 127.0.0.1
ipconfig /flushdns

# 4. 浏览器访问 http://www.baidu.com/   → 应看到钓鱼页

# 5. 演示完恢复 DNS
netsh interface ip set dns "以太网" dhcp
ipconfig /flushdns
```

把 `"以太网"` 换成第 1 步看到的实际网卡名（可能是 `"WLAN"`、`"Wi-Fi"` 等）。

### 演示期间会发生什么

- `www.baidu.com` → 解析到 `127.0.0.1` → 钓鱼页
- **其他域名** → 转发给上游 DNS（默认 `223.5.5.5`），**正常访问**
- 想模拟「DNS 被完全控制」，加 `--upstream ""`，其他网站会打不开

### 端口冲突

**53 端口被占**（常见于 Internet Connection Sharing 服务）：

```powershell
netstat -ano | findstr :53      # 看是谁占着
net stop SharedAccess           # 或临时停掉 ICS
```

**80 端口被占**（IIS、Skype 等）：可以 `--web-port 8080`，但那样浏览器得
手动带端口访问，演示不方便 —— 建议先腾出 80。

---

## lan 模式操作步骤

**先确认你已获得授权。**

```powershell
# 1. 看网卡名和本机 IP
ipconfig

# 2. 起攻击（管理员 PowerShell）
python dns-hijack-win.py lan --iface "以太网" --target 192.168.1.50 --gateway 192.168.1.1
```

- `--target` 受害者机器 IP
- `--gateway` 被冒充的网关（`ipconfig` 里的默认网关）
- 脚本会先让你输入 `yes` 确认

**停止后**立刻在目标机器上执行（管理员）：

```cmd
arp -d *
```

或等 ARP 表自己老化。

### 关于目标机器断网（参考做法，未实测）

ARP 欺骗只把 DNS 查询引过来。但如果你冒充的是**默认网关**，目标机的其他
流量也会经过你 —— 不开转发它就会断网。在 Windows 上开启转发需要在注册表
里设 `IPEnableRouter = 1` 并重启，影响面更大。

**课堂演示更推荐只用 local 模式**，或者用 Linux 版的 netns 靶场（完全隔离，
零副作用）。

---

## 验证边界（重要，请先读）

| 项目 | 状态 |
|------|------|
| DNS 劫持指定域名 → 伪造 IP | **已实测**（含 Windows） |
| 非目标域名转发上游 | **已实测** |
| 假站返回钓鱼页 | **已实测** |
| 绑定本机 53 / 80 | **已在 Windows 实测**（若失败见下方端口冲突） |
| `netsh` 改系统 DNS + 浏览器实操 | 需管理员自行点一次确认 |
| 防火墙拦截 | 视本机策略而定 |
| `lan` + Npcap | **非课堂默认路径**；需授权，且校园网装 Npcap 常被 `8021x.exe` 占用 |

### Npcap 安装被 `8021x.exe` 占用时

仅 `lan` 模式需要。可临时停止后再装（可能影响有线 802.1X 认证）：

```powershell
Stop-Service dot3svc, EapHost -Force -ErrorAction SilentlyContinue
Stop-Process -Name 8021x -Force -ErrorAction SilentlyContinue
# 安装 Npcap（勾选 WinPcap API-compatible Mode）
Start-Service EapHost, dot3svc
```

课堂只用 `local` 时可**跳过 Npcap**。

---

## 安全边界

**local 模式是安全的**：只改本机 DNS 指向，服务只监听本机，演示完把 DNS
改回自动获取即可，无残留。

**lan 模式是对真实网络的攻击**，只应在你拥有或被明确授权的网络里、对你
自己的或已同意的测试机使用。校园网、公司网、公共网络上一律不要用。

---

## 与其他材料的关系

- `lab.sh` + `dns-spoof.py` —— **Linux 版**，用 network namespace 做完全
  隔离的靶场，**首选**（不受任何真实网络影响）
- `dns-hijack-win.py` —— **Windows 版**，没有 netns 可用，只能在
  「本地安全」和「局域网需授权」之间取舍
