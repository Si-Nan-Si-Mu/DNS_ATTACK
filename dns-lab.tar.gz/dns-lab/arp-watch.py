#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
观测目标机的网关 MAC 归属：先发一轮修正 ARP，然后盯着看它会不会变回去。

用法：
    sudo python3 arp-watch.py <网卡> <目标IP> <目标MAC> <网关IP> <网关MAC> [观测秒数]
"""
import sys
import time
from collections import Counter

try:
    from scapy.all import ARP, Ether, IP, AsyncSniffer, sendp
except ImportError:
    sys.exit("[x] 需要 scapy：pip install scapy")

iface, tip, tmac, gip, gmac = sys.argv[1:6]
DUR = int(sys.argv[6]) if len(sys.argv) > 6 else 40
BCAST = "ff:ff:ff:ff:ff:ff"
DUMMY = "00:00:00:00:00:00"

events = []      # (时间, 目标机发出的包的目的MAC)
arp_log = []     # 与目标/网关相关的 ARP
last_mac = None


def handle(p):
    global last_mac
    if p.haslayer(ARP):
        a, e = p[ARP], p[Ether]
        if tip in (a.psrc, a.pdst) or gip in (a.psrc, a.pdst):
            op = "请求" if a.op == 1 else "应答"
            arp_log.append(f"{time.strftime('%H:%M:%S')} {op} "
                           f"{e.src}->{e.dst}  {a.psrc} 问/告 {a.pdst}")
    elif p.haslayer(IP) and p[IP].src == tip:
        d = p[Ether].dst.lower()
        if d != last_mac:
            last_mac = d
            events.append((time.strftime("%H:%M:%S"), d))


sn = AsyncSniffer(iface=iface, prn=handle, store=False)
sn.start()
time.sleep(0.5)

pkts = {
    "单播ARP请求": Ether(src=gmac, dst=tmac) / ARP(op=1, psrc=gip, hwsrc=gmac, pdst=tip, hwdst=tmac),
    "单播ARP应答": Ether(src=gmac, dst=tmac) / ARP(op=2, psrc=gip, hwsrc=gmac, pdst=tip, hwdst=tmac),
    "广播ARP请求": Ether(src=gmac, dst=BCAST) / ARP(op=1, psrc=gip, hwsrc=gmac, pdst=gip, hwdst=DUMMY),
    "广播ARP应答": Ether(src=gmac, dst=BCAST) / ARP(op=2, psrc=gip, hwsrc=gmac, pdst=gip, hwdst=DUMMY),
}
for name, pkt in pkts.items():
    sendp(pkt, iface=iface, count=4, inter=0.25, verbose=False)
    print(f"[watch] 已发 4x {name}")

print(f"[watch] 开始观测 {DUR} 秒 ...")
time.sleep(DUR)
sn.stop()

print("\n=== 目标机出流量指向的 MAC（变化时间线）===")
if not events:
    print("  （没看到目标机流量）")
for t, d in events:
    if d == "82:f7:ff:cd:77:10":
        tag = "Kali —— 仍被引向攻击机"
    elif d == gmac.lower():
        tag = "真实网关 —— 已修正"
    else:
        tag = "其它/广播"
    print(f"  {t}  dst={d}   {tag}")

print("\n=== 期间观察到的相关 ARP ===")
if not arp_log:
    print("  （没有任何 ARP 交互 —— 说明目标机没有发起重新解析）")
for line in arp_log[:30]:
    print("  " + line)

c = Counter(d for _, d in events)
print("\n=== 汇总 ===")
for mac, n in c.most_common():
    print(f"  {mac}: 出现 {n} 次（按时间段计）")
