#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
纠正「网关」的邻居表 —— ARP 欺骗+转发留下的第二个坑。

背景：
  Kali 转发目标机的上行包时，以太网源 MAC 是 Kali 自己的，但 IP 源仍是目标机。
  网关收到后会把「目标机 IP → Kali MAC」记进自己的邻居表，于是回包全部发往
  Kali。即使目标机自己清了 ARP 缓存，只要 Kali 还在转发，网关邻居表就会反复
  被污染，形成双向自维持的死循环。

做法：
  以「目标机」的身份向网关宣告目标机的真实 IP-MAC 映射（gratuitous ARP 广播 +
  单播 ARP 应答），把网关邻居表纠正回来。

用法：
    sudo python3 arp-fix-gw.py <网卡> <目标IP> <目标MAC> <网关IP> <网关MAC>
"""
import sys

try:
    from scapy.all import ARP, Ether, sendp
except ImportError:
    sys.exit("[x] 需要 scapy：pip install scapy")

iface, tip, tmac, gip, gmac = sys.argv[1:6]
BCAST = "ff:ff:ff:ff:ff:ff"
DUMMY = "00:00:00:00:00:00"

ann = Ether(src=tmac, dst=BCAST) / ARP(op=1, psrc=tip, hwsrc=tmac,
                                      pdst=tip, hwdst=DUMMY)
rep = Ether(src=tmac, dst=gmac) / ARP(op=2, psrc=tip, hwsrc=tmac,
                                      pdst=gip, hwdst=gmac)

sendp(ann, iface=iface, count=5, inter=0.3, verbose=False)
sendp(rep, iface=iface, count=5, inter=0.3, verbose=False)

print(f"[arp-fix-gw] 已向网关宣告：{tip} 的真实 MAC = {tmac}")
print("[arp-fix-gw] 5x 广播 gratuitous ARP + 5x 单播 ARP 应答")
