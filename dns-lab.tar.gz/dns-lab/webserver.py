#!/usr/bin/env python3
"""
靶场用极简 Web 服务器。

用途：在 netns 里跑起一个「网站」，用不同的标题/配色区分
       - ns-gw  上的「真实网站」（正常 DNS 会把你带到这）
       - ns-att 上的「伪造网站」（DNS 被劫持后你会到这）

日志打到 stderr，会被 lab.sh 收进 run/<name>.log，
这样演示时能直接看到「谁访问了哪个站点」。
"""
import datetime
import http.server
import socketserver
import sys

TITLE = sys.argv[1] if len(sys.argv) > 1 else "WEB"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 80
HEADLINE = sys.argv[3] if len(sys.argv) > 3 else TITLE
ACCENT = sys.argv[4] if len(sys.argv) > 4 else "#2e7d32"

PAGE = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{TITLE}</title>
<style>
  body {{ margin:0; font-family: system-ui, "Noto Sans CJK SC", sans-serif;
         background:#111; color:#eee; display:flex; align-items:center;
         justify-content:center; height:100vh; }}
  .card {{ border:2px solid {ACCENT}; border-radius:12px; padding:2.5rem 3.5rem;
           text-align:center; box-shadow:0 0 40px {ACCENT}55; }}
  h1 {{ color:{ACCENT}; margin:0 0 .6rem; font-size:2rem; }}
  p  {{ margin:.3rem 0; color:#aaa; }}
  code {{ color:#eee; background:#000; padding:.15rem .4rem; border-radius:4px; }}
</style>
</head>
<body>
  <div class="card">
    <h1>{HEADLINE}</h1>
    <p>hostname: <code>{TITLE}</code></p>
    <p>你看到的这一页，来自 DNS 解析结果指向的那台主机。</p>
  </div>
</body>
</html>
"""


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "LabHTTP/1.0"

    def do_GET(self):
        body = PAGE.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        sys.stderr.write(f"[{ts}] {self.client_address[0]} -> {self.path}\n")
        sys.stderr.flush()


class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


if __name__ == "__main__":
    with ReusableTCPServer(("0.0.0.0", PORT), Handler) as httpd:
        print(f"[webserver] {TITLE} listening on 0.0.0.0:{PORT}", flush=True)
        httpd.serve_forever()
