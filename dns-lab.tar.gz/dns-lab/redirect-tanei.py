#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DNS 劫持演示 —— 跳转版

比起「仿冒页面」，这个版本更简单也更稳：

    受害者访问 www.baidu.com
      → DNS 被劫持到攻击者机器
      → 攻击者返回 302 跳转
      → 浏览器自己跳到真实的 www.tanei.top

好处是用的是真实网站的**合法证书**，不会出现自签证书警告，演示顺畅。
教学上同样说明问题：域名解析被篡改后，用户会被引导到攻击者指定的
任意站点 —— 真实攻击里那个站点换成钓鱼页即可。

用法：
    python3 redirect-tanei.py [http端口] [证书路径] [私钥路径] [跳转目标URL]

跳转目标不传的话默认为 https://www.tanei.top/
例如把访问跳到百度：
    python3 redirect-tanei.py 80 cert.pem key.pem https://www.baidu.com/
"""
import datetime
import http.server
import socketserver
import ssl
import sys
import threading

# 跳转目标：可由第 4 个命令行参数覆盖，默认跳到 tanei.top
TARGET = sys.argv[4] if len(sys.argv) > 4 else "https://www.tanei.top/"


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "LabRedirect/1.0"

    def _redirect(self):
        self.send_response(302)
        self.send_header("Location", TARGET)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        self._redirect()
        self._log()

    def do_HEAD(self):
        self._redirect()
        self._log()

    def _log(self):
        host = self.headers.get("Host", "?")
        proto = "HTTPS" if isinstance(self.connection, ssl.SSLSocket) else "HTTP"
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        sys.stderr.write(f"[{ts}] {self.client_address[0]} {proto} "
                         f"{self.path}（Host: {host}）→ 302 {TARGET}\n")
        sys.stderr.flush()

    def log_message(self, fmt, *args):
        pass          # 用上面的 _log 就够了


class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


class SecureServer(ReusableTCPServer):
    """accept 之后再做 TLS 包装，自签证书握手失败时静默忽略"""

    def __init__(self, addr, handler, ctx):
        self.ctx = ctx
        super().__init__(addr, handler)

    def get_request(self):
        sock, addr = self.socket.accept()
        try:
            return self.ctx.wrap_socket(sock, server_side=True), addr
        except (ssl.SSLError, OSError):
            try:
                sock.close()
            except OSError:
                pass
            raise


def run_http(port):
    with ReusableTCPServer(("0.0.0.0", port), Handler) as s:
        print(f"[redirect] HTTP  监听 0.0.0.0:{port} → {TARGET}", flush=True)
        s.serve_forever()


def run_https(port, cert, key):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=cert, keyfile=key)
    with SecureServer(("0.0.0.0", port), Handler, ctx) as s:
        print(f"[redirect] HTTPS 监听 0.0.0.0:{port}（自签证书）→ {TARGET}",
              flush=True)
        s.serve_forever()


if __name__ == "__main__":
    http_port = int(sys.argv[1]) if len(sys.argv) > 1 else 80
    cert = sys.argv[2] if len(sys.argv) > 3 else None
    key = sys.argv[3] if len(sys.argv) > 3 else None

    threads = [threading.Thread(target=run_http, args=(http_port,), daemon=True)]
    if cert and key:
        threads.append(
            threading.Thread(target=run_https, args=(443, cert, key), daemon=True))
    else:
        print("[redirect] 未提供证书，只监听 HTTP", flush=True)

    for t in threads:
        t.start()
    for t in threads:
        t.join()
