#!/usr/bin/env python3
"""
仿百度钓鱼页 —— DNS 劫持课堂演示专用。

受害者想访问 www.baidu.com，DNS 被劫持后落到这个页面。

同时监听 80(HTTP) 和 443(HTTPS，自签证书)：
  - 现代浏览器访问 www.baidu.com 往往直接走 HTTPS，只监听 80 会连接失败
  - 监听 443 后，浏览器会弹出「证书不受信任」警告 —— 这正是真实钓鱼
    场景的关键一环：攻击者用自签证书，赌你会点「继续访问」

用法：
    python3 fake-baidu.py [http端口] [证书路径] [私钥路径]
"""
import datetime
import http.server
import socketserver
import ssl
import sys
import threading

PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>百度一下，你就知道</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: Arial, "Microsoft YaHei", "PingFang SC", sans-serif;
         background:#fff; min-height:100vh; }
  .warn { background:#c62828; color:#fff; padding:14px 24px; font-size:15px;
          text-align:center; line-height:1.5; }
  .warn b { font-size:16px; }
  .wrap { max-width:680px; margin:60px auto 0; text-align:center; }
  .logo { font-size:52px; color:#2932e1; font-weight:bold; letter-spacing:1px; }
  .logo small { font-size:26px; color:#2932e1; font-weight:normal; margin-left:6px; }
  .search { margin-top:36px; display:flex; justify-content:center; }
  .search input { width:420px; padding:12px 16px; font-size:16px;
                  border:2px solid #2932e1; border-radius:4px 0 0 4px;
                  outline:none; }
  .search button { padding:12px 26px; font-size:16px; color:#fff;
                   background:#2932e1; border:2px solid #2932e1;
                   border-radius:0 4px 4px 0; cursor:pointer; }
  .tip { margin-top:22px; color:#666; font-size:14px; }
  .proto { margin-top:10px; color:#999; font-size:13px; }
  .footer { position:fixed; bottom:0; left:0; right:0; padding:14px;
            text-align:center; color:#999; font-size:13px;
            border-top:1px solid #eee; background:#fafafa; }
  .footer a { color:#2932e1; text-decoration:none; }
</style>
</head>
<body>
  <div class="warn">
    <b>⚠ 这是一次 DNS 劫持演示</b><br>
    你访问的是 <b>www.baidu.com</b>，但域名解析已被攻击者篡改，<br>
    现在你看到的是<b>攻击者服务器</b>上的页面，而不是真正的百度。
  </div>
  <div class="wrap">
    <div class="logo">Baidu<small>百度</small></div>
    <div class="search">
      <input type="text" placeholder="输入任何内容，都不会真的搜索（演示用）">
      <button type="button">百度一下</button>
    </div>
    <div class="tip">此页面仅为教学演示而构造，与真实百度无关</div>
    <div class="proto" id="proto"></div>
  </div>
  <div class="footer">
    钓鱼演示页 · <a href="http://www.tanei.top/">TANEI·计算机社团</a> · www.tanei.top
  </div>
  <script>
    // 把「当前是通过 HTTP 还是 HTTPS 访问的」显示出来，
    // 方便课堂上对照浏览器地址栏的锁图标 / 证书警告。
    document.getElementById('proto').textContent =
      '当前连接方式：' + location.protocol.replace(':', '').toUpperCase();
  </script>
</body>
</html>
"""


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "LabHTTP/1.0"

    def do_GET(self):
        body = PAGE.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        proto = "HTTPS" if isinstance(self.connection, ssl.SSLSocket) else "HTTP"
        sys.stderr.write(f"[{ts}] {self.client_address[0]} {proto} "
                         f"{self.path}（Host: {self.headers.get('Host', '?')}）\n")
        sys.stderr.flush()


class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


class SecureServer(ReusableTCPServer):
    """在 accept 之后对连接做 TLS 包装，可以正确处理自签证书握手失败。"""

    def __init__(self, addr, handler, ctx):
        self.ctx = ctx
        super().__init__(addr, handler)

    def get_request(self):
        sock, addr = self.socket.accept()
        try:
            return self.ctx.wrap_socket(sock, server_side=True), addr
        except (ssl.SSLError, OSError):
            # 浏览器拒绝自签证书时会中断握手，这是预期行为，忽略即可
            try:
                sock.close()
            except OSError:
                pass
            raise


def run_http(port):
    with ReusableTCPServer(("0.0.0.0", port), Handler) as httpd:
        print(f"[fake-baidu] HTTP  监听 0.0.0.0:{port}", flush=True)
        httpd.serve_forever()


def run_https(port, cert, key):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=cert, keyfile=key)
    with SecureServer(("0.0.0.0", port), Handler, ctx) as httpd:
        print(f"[fake-baidu] HTTPS 监听 0.0.0.0:{port}（自签证书）", flush=True)
        httpd.serve_forever()


if __name__ == "__main__":
    http_port = int(sys.argv[1]) if len(sys.argv) > 1 else 80
    cert = sys.argv[2] if len(sys.argv) > 3 else None
    key = sys.argv[3] if len(sys.argv) > 3 else None

    threads = [threading.Thread(target=run_http, args=(http_port,), daemon=True)]
    if cert and key:
        threads.append(
            threading.Thread(target=run_https, args=(443, cert, key), daemon=True))
    else:
        print("[fake-baidu] 未提供证书，只监听 HTTP（443 不会响应）", flush=True)

    for t in threads:
        t.start()
    for t in threads:
        t.join()
