#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARP 表修复（增强版）—— 停止 ARP 欺骗后，把目标机的 ARP 缓存纠正回来。

与 arp-fix.py 的区别：
  arp-fix.py 只发 ARP 应答（op=2）。Windows 对处于 Reachable 状态的邻居条目
  会忽略这种未经请求的应答，因此实测无效。
  本脚本额外发送 ARP 请求（op=1，源=网关），Windows 收到「网关主动询问我」
  的请求时，会用其中携带的 IP-MAC 映射更新自己的缓存 —— 实测有效。

用法：
    sudo python3 arp-fix-req.py <网卡> <目标IP> <目标MAC> <网关IP> <网关MAC>
"""
import sys

try:
    from scapy.all import ARP, Ether, sendp
except ImportError:
    sys.exit("[x] 需要 scapy：pip install scapy（或 apt install python3-scapy）")


def main():
    if len(sys.argv) != 6:
        sys.exit(__doc__.strip())

    iface, tgt_ip, tgt_mac, gw_ip, gw_mac = sys.argv[1:6]

    req = Ether(src=gw_mac, dst=tgt_mac) / ARP(
        op=1, psrc=gw_ip, hwsrc=gw_mac, pdst=tgt_ip, hwdst=tgt_mac)
    rep = Ether(src=gw_mac, dst=tgt_mac) / ARP(
        op=2, psrc=gw_ip, hwsrc=gw_mac, pdst=tgt_ip, hwdst=tgt_mac)

    sendp(req, iface=iface, count=6, inter=0.25, verbose=False)
    sendp(rep, iface=iface, count=6, inter=0.25, verbose=False)

    print(f"[arp-fix-req] 已向 {tgt_ip} 发送 6x ARP请求 + 6x ARP应答")
    print(f"[arp-fix-req] 声明 {gw_ip} 的真实 MAC = {gw_mac}")
    print("[arp-fix-req] 若目标机仍异常，请在它上面执行： arp -d *  （Windows 管理员）")


if __name__ == "__main__":
    main()
