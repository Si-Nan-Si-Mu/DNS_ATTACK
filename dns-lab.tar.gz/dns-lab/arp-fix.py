#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARP 表修复 —— 停止 ARP 欺骗后，把目标机的 ARP 缓存纠正回来。

原理：以「网关」的身份，向目标机发送正确的 ARP 应答，告诉它网关的真实
MAC 地址。这样目标机就不会再往攻击者那边发包了。

用法：
    python3 arp-fix.py <网卡> <目标IP> <目标MAC> <网关IP> <网关MAC>

示例：
    python3 arp-fix.py eth0 10.255.1.50 aa:bb:cc:dd:ee:ff 10.255.0.1 14:14:4b:7d:4a:65
"""
import sys

try:
    from scapy.all import ARP, Ether, sendp
except ImportError:
    sys.exit("[x] 需要 scapy：pip install scapy（或 apt install python3-scapy）")


def main():
    if len(sys.argv) != 6:
        sys.exit(__doc__.strip())

    iface, target_ip, target_mac, gw_ip, gw_mac = sys.argv[1:6]

    # 以网关的身份回正确的 ARP 应答，发 5 次确保目标收到
    pkt = (Ether(src=gw_mac, dst=target_mac) /
           ARP(op=2, psrc=gw_ip, hwsrc=gw_mac, pdst=target_ip, hwdst=target_mac))
    sendp(pkt, iface=iface, count=5, inter=0.3, verbose=False)

    print(f"[arp-fix] 已向 {target_ip} 发送 5 次正确 ARP"
          f"（{gw_ip} 的 MAC = {gw_mac}）")
    print(f"[arp-fix] 如果目标机仍异常，请在它上面执行： arp -d *   （Windows）"
          f" 或  ip neigh flush all   （Linux）")


if __name__ == "__main__":
    main()
